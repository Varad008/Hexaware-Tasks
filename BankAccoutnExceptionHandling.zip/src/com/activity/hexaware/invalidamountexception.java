package com.activity.hexaware;

public class invalidamountexception extends Exception {
    public invalidamountexception(String message) {
        super(message);
    }
}
