package com.activity.hexaware;

public class insufficientfundexception extends Exception {
    public insufficientfundexception(String message) {
        super(message);
    }
}

