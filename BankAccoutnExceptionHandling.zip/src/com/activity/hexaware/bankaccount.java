package com.activity.hexaware;

public class bankaccount {
	
    private double balance;

    public bankaccount(double initialDeposit) throws invalidamountexception {
        if (initialDeposit < 0) {
            throw new invalidamountexception("Initial deposit cannot be negative.");
        }
        this.balance = initialDeposit;
    }

    public void deposit(double amount) throws invalidamountexception {
        if (amount <= 0) {
            throw new invalidamountexception("Deposit amount must be greater than zero.");
        }
        balance += amount;
        System.out.println("Deposit successful. Current balance: " + balance);
    }

    public void withdraw(double amount) throws insufficientfundexception, invalidamountexception {
        if (amount <= 0) {
            throw new invalidamountexception("Withdrawal amount must be greater than zero.");
        }
        if (amount > balance) {
            throw new insufficientfundexception("Insufficient funds.");
        }
        balance -= amount;
        System.out.println("Withdrawal successful. Current balance: " + balance);
    }

    public double getBalance() {
        return balance;
    }
}
