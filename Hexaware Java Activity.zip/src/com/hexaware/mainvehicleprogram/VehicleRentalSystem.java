package com.hexaware.mainvehicleprogram;
import com.hexaware.abstractclasses.Vehicle;
import com.hexaware.concreteclasses.Bike;
import com.hexaware.concreteclasses.Car;
import com.hexaware.concreteclasses.Truck;


import java.util.Scanner;

public class VehicleRentalSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create vehicles
        Vehicle car = new Car("Honda Civic", 50);
        Vehicle bike = new Bike("Yamaha MT", 20);
        Vehicle truck = new Truck("Ford F-150", 100);

        // Create user
        User user = new User("John Doe");

        // Menu-based system
        while (true) {
            System.out.println("\nVehicle Rental System");
            System.out.println("1. Rent Car");
            System.out.println("2. Rent Bike");
            System.out.println("3. Rent Truck");
            System.out.println("4. Return Car");
            System.out.println("5. Return Bike");
            System.out.println("6. Return Truck");
            System.out.println("7. View Rented Vehicles");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    user.rentVehicle(car);
                    break;
                case 2:
                    user.rentVehicle(bike);
                    break;
                case 3:
                    user.rentVehicle(truck);
                    break;
                case 4:
                    user.returnVehicle(car);
                    break;
                case 5:
                    user.returnVehicle(bike);
                    break;
                case 6:
                    user.returnVehicle(truck);
                    break;
                case 7:
                    user.showRentedVehicles();
                    break;
                case 8:
                    System.out.println("Exiting system...");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
