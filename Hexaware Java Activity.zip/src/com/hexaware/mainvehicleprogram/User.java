package com.hexaware.mainvehicleprogram;
import java.util.ArrayList;

import com.hexaware.abstractclasses.Vehicle;

class User {
    private String name;
    private ArrayList<Vehicle> rentedVehicles;

    public User(String name) {
        this.name = name;
        this.rentedVehicles = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void rentVehicle(Vehicle vehicle) {
        if (!vehicle.isRented()) {
            vehicle.rentVehicle();
            rentedVehicles.add(vehicle);
        } else {
            System.out.println(vehicle.getName() + " is already rented.");
        }
    }

    public void returnVehicle(Vehicle vehicle) {
        if (rentedVehicles.contains(vehicle)) {
            vehicle.returnVehicle();
            rentedVehicles.remove(vehicle);
        } else {
            System.out.println(vehicle.getName() + " is not rented by " + name + ".");
        }
    }

    public void showRentedVehicles() {
        if (rentedVehicles.isEmpty()) {
            System.out.println(name + " has not rented any vehicles.");
        } else {
            System.out.println(name + " has rented the following vehicles:");
            for (Vehicle v : rentedVehicles) {
                System.out.println("- " + v.getName());
            }
        }
    }
}

