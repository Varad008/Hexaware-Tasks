package com.hexaware.abstractclasses;

public abstract class Vehicle {
    private String name;
    private double pricePerDay;
    private boolean isRented;

    public Vehicle(String name, double pricePerDay) {
        this.name = name;
        this.pricePerDay = pricePerDay;
        this.isRented = false;
    }
    
    
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    
    
    public void setPricePerDay(double pricePerDay) {
        this.pricePerDay = pricePerDay;
    }

    public double getPricePerDay() {
        return pricePerDay;
    }
    
    
    
    public void setRented(boolean rented) {
        isRented = rented;
    }

    	
    public boolean isRented() {
        return isRented;
    }

    

    public abstract void rentVehicle();

    public abstract void returnVehicle();
}
